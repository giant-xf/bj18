CREATE VIEW python.v_stu_sub_sco AS
  SELECT
    `stu`.`id`     AS `id`,
    `stu`.`name`   AS `name`,
    `sub`.`stitle` AS `stitle`,
    `sco`.`score`  AS `score`
  FROM ((`python`.`scores` `sco`
    JOIN `python`.`students` `stu` ON ((`stu`.`id` = `sco`.`stuid`))) JOIN `python`.`subjects` `sub`
      ON ((`sub`.`id` = `sco`.`subid`)));
